package com.example.kotlinproject

class Timetable {
}